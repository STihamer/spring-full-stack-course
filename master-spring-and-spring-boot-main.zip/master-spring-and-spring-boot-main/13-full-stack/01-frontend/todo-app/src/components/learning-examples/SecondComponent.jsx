export default function SecondComponent() {
  return (
    <div className="SecondComponent">Second Component</div>
  )
}